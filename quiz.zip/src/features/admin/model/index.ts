import { loginModel } from './login'

export const adminModel = {
    loginModel
}
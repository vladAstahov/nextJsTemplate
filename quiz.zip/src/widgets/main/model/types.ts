export type ActiveQuiz = {
    name: string;
    link: string;
    date: string;
    time: string;
    price: string;
    limit: string;
}
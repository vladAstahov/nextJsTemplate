export type Promo = {
    id?: string
    quizId: string
    name: string
    limit: number
    passed?: number
}
export type Main = {
    id: number
    title: string,
    description: string
    time: string
    date: string
    quizId: string
    price: string
}
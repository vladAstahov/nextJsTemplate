export default function Title() {

    return (
        <main>
            <h1>Title</h1>

        </main>
    )
}
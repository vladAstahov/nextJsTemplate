declare global {
    type PropsDefault = {
        className?: string
    }
}